import requests

from skynetapi.serializable import Serializable
from skynetapi.utils.string import snake_to_camel


class HTTPRequest:
    def __init__(self, token: str):
        self.token = token
        self._version = '2.0'
        self._url = f'https://api.skynet.unc.edu/{self.version}'

        self._endpoints = ('obs', 'exps', 'download', 'scopes', 'filters')
        self._methods = ('GET', 'POST', 'PUT', 'HEAD', 'OPTIONS')

    @property
    def url(self) -> str:
        return self._url

    @property
    def version(self) -> str:
        return self._version

    @property
    def endpoints(self) -> tuple:
        return self._endpoints

    @property
    def methods(self) -> tuple:
        return self._methods

    def request(self, method: str, endpoint: str, **kwargs):
        """ Sends a http request to the Skynet Observation API and returns
        the response if request was successful.

        :param method: HTTP request operation
        :param endpoint: Skynet API endpoint
        :param kwargs: any attribute, value pair defined in api.endpoints.observation
        :return: requests.Response object
        """
        if method.upper() not in self.methods:
            raise ValueError(f"HTTP method  must be one of: {', '.join(self.methods)}.")

        if endpoint not in self.endpoints:
            raise ValueError(f"Endpoint must be one of {', '.join(self.endpoints)}")

        payload = {'headers': {'Authentication-Token': self.token}}

        if (_id := kwargs.pop('id', '')) and method.upper() == 'GET':
            payload['data'] = {}
        elif method.upper() in ('GET', 'HEAD', 'OPTIONS'):
            payload['params'] = {snake_to_camel(k): v for k, v in kwargs.items()}
        else:
            payload['data'] = {snake_to_camel(k): v for k, v in kwargs.items()}

        response = requests.request(method=method.upper(), url=f"{self.url}/{endpoint}/{_id}", **payload)

        if response.status_code != 200:
            raise RuntimeError(response.text)

        return response.json() if isinstance(response.json(), list) else Serializable(**response.json())
